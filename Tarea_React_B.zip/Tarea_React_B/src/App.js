import './App.css';
import Titulo from './components/Titulo'
import Logo from './components/Logo'
import LogoCandado from './components/LogoCandado';
import Parrafo from './components/Parrafo';
import EtiquetaUsuario from './components/EtiquetaUsuario';
import ComentarioUsuario from './components/ComentarioUsuario';
import EtiquetaContraseña from './components/EtiquetaContraseña';
import ComentarioContraseña from './components/ComentarioContraseña';
import EtiquetaConfirmacion from './components/EtiquetaConfirmacion';
import ComentarioConfirmacion from './components/ComentarioConfirmacion';
import Boton from './components/Boton';

function App() {
  return (
    <div className='bg-light-subtle'>
      <Logo />
      <Titulo />
      <LogoCandado />
      <Parrafo />
      <EtiquetaUsuario />
      <ComentarioUsuario />
      <EtiquetaContraseña />
      <ComentarioContraseña />
      <EtiquetaConfirmacion />
      <ComentarioConfirmacion />
      <Boton />
    </div>
  );
}

export default App;
