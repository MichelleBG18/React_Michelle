import React from 'react'

function EtiquetaUsuario() {
  return (
    <div className='Etiqueta1 Parrafo fs-4'>
        <form>
            <p><label for="ARCA_id">NOMBRE DEL USUARIO</label></p>
            <p><input className='col-9' type="text" name="ARCA" id="ARCA_id" placeholder='Escribe tu nombre de usuario aquí...'/></p>
        </form>
    </div>
  );
}

export default EtiquetaUsuario