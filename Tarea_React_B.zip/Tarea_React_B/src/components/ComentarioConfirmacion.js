import React from 'react'

function ComentarioConfirmacion() {
    return (
        <div  className='text-danger container text-end col-8'>
            <p>*Las contraseñas deben coincidir</p>
        </div>
    );
}


export default ComentarioConfirmacion