import React from 'react'

function Logo() {
  return (
        <div className='LogoArca'>
            <img className='img-fluid' src={require('../imagenes/logo_arca.png')} alt='logo_arca'/>
        </div>
  );
}

export default Logo