import React from 'react'

function LogoCandado() {
  return (
    <div className='LogoCandado'>
        <img className='img-fluid rounded mx-auto d-block' src={require('../imagenes/candadito.png')} alt='candado' width={250}/>
    </div>
  );
}

export default LogoCandado