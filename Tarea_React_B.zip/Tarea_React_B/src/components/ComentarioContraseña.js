import React from 'react'

function ComentarioContraseña() {
    return (
        <div  className='text-danger container text-end col-8'>
            <p>*Se requiere que la contraseña tenga una longitud mínima de 12 caracteres, al menos un caracter especial,</p>
            <p>así como una combinación de letras mayúsculas y minúsculas</p>
        </div>
      );
}

export default ComentarioContraseña