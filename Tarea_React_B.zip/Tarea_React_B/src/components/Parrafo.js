import React from 'react'

function Parrafo() {
  return (
    <div className='text-danger container text-center Parrafo fs-2'>
            <p>Restablezca su nombre de usuario y contraseña ingresando</p>
            <p>sus nuevos dato. Asegúrese de anotarlos, ya que necesitará</p>
            <p>esta información para volver a iniciar sesión.</p>
    </div>
  )
}

export default Parrafo