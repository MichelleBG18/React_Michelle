import React from 'react'

function Titulo() {
  return (
    <div className='container-fluid text-center row align-items-center'>
        <div className='TituloArca'>
            <h1 className='text-danger fw-bold text-xl'>RESTABLECER DATOS</h1>
            <h1 className='text-danger fw-bold text-xl'>DE PRIVACIDAD</h1>
        </div>
    </div>
  );
}

export default Titulo;