import React from 'react'

function EtiquetaConfirmacion() {
    return (
        <div className='Etiquetas2 Parrafo fs-4'>
            <form>
                <p><label for="ARCA2_id">CONFIRMAR CONTRASEÑA</label></p>
                <p><input className='col-9' type="text" name="ARCA2" id="ARCA2_id" placeholder='Escribe tu contraseña aquí...'/></p>
            </form>
        </div>
      );
}

export default EtiquetaConfirmacion