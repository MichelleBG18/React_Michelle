import React from 'react'

function Boton() {
  return (
    <div className='container-fluid Botoncito col-1'>
        <input type="submit" className="btn btn-danger btn-lg" value='Registrar'/>
    </div>
  )
}

export default Boton