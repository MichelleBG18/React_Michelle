import React from 'react'

function ComentarioUsuario() {
  return (
    <div  className='text-danger container text-end col-8'>
        <p>*El nombre de usuario se establecerá como la identificación para acceder a tu cuenta</p>
        <p>Una vez registrado, no será posible modificarlo</p>
    </div>
  );
}

export default ComentarioUsuario