import React from 'react'

function EtiquetaContraseña() {
    return (
        <div className='Etiquetas2 Parrafo fs-4'>
            <form>
                <p><label for="ARCA1_id">CONTRASEÑA</label></p>
                <p><input className='col-9' type="text" name="ARCA1" id="ARCA1_id" placeholder='Escribe tu contraseña aquí...'/></p>
            </form>
        </div>
      );
}

export default EtiquetaContraseña