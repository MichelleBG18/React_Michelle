import React from 'react'

function Titulo() {
  return (
    <div className='Titulo'>
        <h1 className='Encabezado'>API: The Rick and Morty</h1>
    </div>
  )
}

export default Titulo