import React, {useEffect, useState} from 'react'
import Contenedor from './Contenedor';

function FotosPersonajes() {

  const [Personajes, setPersonajes] = useState(null);

  useEffect(()=>{
    fetch("https://rickandmortyapi.com/api/character/1,2,3,4,5")
    .then(res => res.json())
    .then(data => {
        console.log(data);
        setPersonajes(data);
    });
  }, []);

  return (
    <div>
        {Personajes && 
            Personajes.map((personaje) => (
                <div key={personaje.id}>
                    <Contenedor name={personaje.name} image={personaje.image} status={personaje.status} species={personaje.species} gender={personaje.gender}/>
                </div>
            ))}
    </div>
  );
}

export default FotosPersonajes