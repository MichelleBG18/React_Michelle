import React from 'react'

function Final() {
  return (
    <div className='Final'>
        <p>API de donde saqué los datos <a href="https://rickandmortyapi.com/" className="link-success link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Link</a></p>
        <p>Link en el fetch "https://rickandmortyapi.com/api/character/1,2,3,4,5" </p>
    </div>
  )
}

export default Final