import React from 'react'

function Nombre() {
  return (
    <div className='Nombre'>
        <h3 className='TituloNombre'>Michelle Bojórquez Gómez | A00833416</h3>
    </div>
  )
}

export default Nombre