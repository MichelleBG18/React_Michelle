import React from 'react'

function Contenedor(props) {
  return (
    <div className='MiPropiaCard card mb-3 text-bg-secondary p-3'>
        <div className='row g-0'>
            <div className='col-md-4'>
                <img src={props.image} className='img-fluid rounded-start' alt=''/>
            </div>
            <div className='card-body'>
                <h5 className='card-title'>{props.name}</h5>
                <ul className='list-group list-group-flush'>
                    <li className='list-group-item list-group-item-primary'>Status = {props.status}</li>
                    <li className='list-group-item list-group-item-primary'>Species = {props.species}</li>
                    <li className='list-group-item list-group-item-primary'>Gender = {props.gender}</li>
                </ul>
            </div>
        </div>
    </div>
  )
}

export default Contenedor