import './App.css';
import Final from './componentes/Final';
import FotosPersonajes from './componentes/FotosPersonajes';
import Nombre from './componentes/Nombre';
import Titulo from './componentes/Titulo';

function App() {
  return (
    <div className='App'>
      <Titulo />
      <Nombre />
      <FotosPersonajes />
      <Final />
    </div>
  );
}

export default App;
